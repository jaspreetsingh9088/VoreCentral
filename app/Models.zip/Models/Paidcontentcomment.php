<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Paidcontentcomment extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'content_id',
        'comment',
    ];
    
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
