<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('username')->after('id');
            $table->string('image')->after('email');
            $table->boolean('status')->after('password')->default(false);
            $table->date('dob')->after('password');
            $table->text('maincontent')->after('password');
            $table->text('oldaccount')->after('password');
            $table->text('quicksummary')->after('password');
            $table->text('subgenres')->after('password');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('username');
            $table->dropColumn('image');
            $table->dropColumn('dob');
            $table->dropColumn('maincontent');
            $table->dropColumn('oldaccount');
            $table->dropColumn('quicksummary');
            $table->dropColumn('subgenres');
        });
    }
};
